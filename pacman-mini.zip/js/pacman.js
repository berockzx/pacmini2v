
(() => {
  let IN_SPXI = false;

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const scoreEl = document.getElementById('score');
  const livesEl = document.getElementById('lives');
  const restartBtn = document.getElementById('btn-restart');

  const TILE = 20;
  const ROWS = 31; // 620 / 20
  const COLS = 28; // 560 / 20

  // Maze legend: 0 empty, 1 wall, 2 dot, 3 power dot
  const maze = (() => {
    const m = Array.from({length: ROWS}, () => Array(COLS).fill(2));
    // border walls
    for (let r=0;r<ROWS;r++){ m[r][0]=1; m[r][COLS-1]=1; }
    for (let c=0;c<COLS;c++){ m[0][c]=1; m[ROWS-1][c]=1; }
    // clear starting area
    for (let r=14;r<=16;r++){ for (let c=13;c<=14;c++){ m[r][c]=0; } }
    // helper to draw walls
    const wall = (r0,c0,r1,c1)=>{
      for (let r=Math.min(r0,r1); r<=Math.max(r0,r1); r++){
        for (let c=Math.min(c0,c1); c<=Math.max(c0,c1); c++){
          m[r][c]=1;
        }
      }
    };
    // interior walls (simple pattern)
    wall(2,2,2,COLS-3); wall(ROWS-3,2,ROWS-3,COLS-3);
    wall(2,2,ROWS-3,2); wall(2,COLS-3,ROWS-3,COLS-3);
    wall(4,4,4,COLS-5); wall(6,2,6,COLS-3); wall(8,4,8,COLS-5);
    wall(10,2,10,COLS-3); wall(12,4,12,COLS-5);
    wall(18,2,18,COLS-3); wall(20,4,20,COLS-5);
    wall(22,2,22,COLS-3); wall(24,4,24,COLS-5); wall(26,2,26,COLS-3);
    // ghost house doors
    for (let c=12;c<=15;c++){ m[14][c]=0; m[16][c]=0; }
    for (let r=12;r<=18;r++){ m[r][13]=0; m[r][14]=0; }
    // power dots
    m[1][1]=3; m[1][COLS-2]=3; m[ROWS-2][1]=3; m[ROWS-2][COLS-2]=3;
    // ensure dots on non-walls
    for (let r=0;r<ROWS;r++){
      for (let c=0;c<COLS;c++){
        if (m[r][c]===1) continue;
        if (m[r][c]!==0 && m[r][c]!==3) m[r][c]=2;
      }
    }
    m[15][14]=0;
    return m;
  })();

  const pacman = {
    r: 15, c: 14, dir: {r:0, c:0}, nextDir: {r:0, c:0}, lives: 3, score: 0, powerTime: 0
  };

  let gameOver = false;
  let raf;

  function isWall(r,c){
    if (r<0||c<0||r>=ROWS||c>=COLS) return true;
    return maze[r][c]===1;
  }
  function wrapCol(c){
    if (c<0) return COLS-1;
    if (c>=COLS) return 0;
    return c;
  }
  function setDir(dr,dc){ pacman.nextDir = { r: dr, c: dc }; }
  function tryApplyNextDir(){
    const nr = pacman.r + pacman.nextDir.r;
    const nc = wrapCol(pacman.c + pacman.nextDir.c);
    if (!isWall(nr,nc)){ pacman.dir = pacman.nextDir; }
  }

  function move(){
    if (gameOver) return;
    tryApplyNextDir();
    const nr = pacman.r + pacman.dir.r;
    const nc = wrapCol(pacman.c + pacman.dir.c);
    if (!isWall(nr,nc)){
      pacman.r = nr; pacman.c = nc;
      const cell = maze[nr][nc];
      if (cell === 2){ pacman.score += 10; maze[nr][nc] = 0; }
      else if (cell === 3){ pacman.score += 50; maze[nr][nc] = 0; pacman.powerTime = 300; }
      scoreEl.textContent = pacman.score;
    } else {
      // simple penalty on wall bump -> life loss example
      if (pacman.lives > 0){
        pacman.lives--;
        livesEl.textContent = pacman.lives;
        pacman.r = 15; pacman.c = 14; pacman.dir={r:0,c:0}; pacman.nextDir={r:0,c:0};
        if (pacman.lives <= 0) onGameOver();
      }
    }
    if (pacman.powerTime > 0) pacman.powerTime--;
  }

  function draw(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    for (let r=0;r<ROWS;r++){
      for (let c=0;c<COLS;c++){
        const x = c*TILE, y = r*TILE;
        if (maze[r][c]===1){
          ctx.fillStyle = '#1f2937'; ctx.fillRect(x,y,TILE,TILE);
          ctx.strokeStyle = '#0ea5e9'; ctx.lineWidth = 2; ctx.strokeRect(x+2,y+2,TILE-4,TILE-4);
        } else if (maze[r][c]===2){
          ctx.fillStyle = '#fbbf24'; ctx.beginPath(); ctx.arc(x+TILE/2, y+TILE/2, 3, 0, Math.PI*2); ctx.fill();
        } else if (maze[r][c]===3){
          ctx.fillStyle = '#f472b6'; ctx.beginPath(); ctx.arc(x+TILE/2, y+TILE/2, 6, 0, Math.PI*2); ctx.fill();
        }
      }
    }
    const px = pacman.c*TILE + TILE/2;
    const py = pacman.r*TILE + TILE/2;
    const mouth = (Date.now()/80|0)%6/20 * Math.PI;
    let angle = 0;
    if (pacman.dir.r===0 && pacman.dir.c===1) angle = 0;
    else if (pacman.dir.r===0 && pacman.dir.c===-1) angle = Math.PI;
    else if (pacman.dir.r===-1) angle = -Math.PI/2;
    else if (pacman.dir.r===1) angle = Math.PI/2;
    ctx.fillStyle = '#fcd34d';
    ctx.beginPath();
    ctx.moveTo(px,py);
    ctx.arc(px,py, 9, angle+mouth, angle+(Math.PI*2 - mouth));
    ctx.closePath();
    ctx.fill();
  }

  function loop(){
    move(); draw();
    if (!gameOver) raf = requestAnimationFrame(loop);
  }

  function onGameOver(){
    if (gameOver) return;
    gameOver = true;
    const message = `🎯 You scored ${pacman.score} points in Pac-Man Mini!`;
    try {
      // send to the current session player
      SpixiAppSdk.sendNetworkData(message);
    } catch(e) {
      console.warn("sendNetworkData failed (outside Spixi?):", e);
      alert(message);
    }
  }

  function restart(){
    gameOver = false;
    pacman.r = 15; pacman.c = 14; pacman.dir={r:0,c:0}; pacman.nextDir={r:0,c:0};
    pacman.lives = 3; pacman.score = 0; pacman.powerTime = 0;
    for (let r=0;r<ROWS;r++){ for (let c=0;c<COLS;c++){ if (maze[r][c]!==1) maze[r][c]=2; } }
    const COLS_VAL = COLS;
    maze[1][1]=3; maze[1][COLS_VAL-2]=3; maze[ROWS-2][1]=3; maze[ROWS-2][COLS_VAL-2]=3;
    maze[15][14]=0;
    scoreEl.textContent = '0'; livesEl.textContent = '3';
    cancelAnimationFrame(raf); loop();
  }

  // UI / input
  window.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if (k === 'arrowup' || k === 'w') setDir(-1,0);
    else if (k === 'arrowdown' || k === 's') setDir(1,0);
    else if (k === 'arrowleft' || k === 'a') setDir(0,-1);
    else if (k === 'arrowright' || k === 'd') setDir(0,1);
    else if (k === 'r') restart();
  });
  document.querySelectorAll('#touch-controls [data-dir]').forEach(btn => {
    btn.addEventListener('click', () => {
      const dir = btn.getAttribute('data-dir');
      if (dir==='up') setDir(-1,0);
      else if (dir==='down') setDir(1,0);
      else if (dir==='left') setDir(0,-1);
      else if (dir==='right') setDir(0,1);
    });
  });
  document.getElementById('btn-restart').addEventListener('click', restart);

  // Hook into Spixi lifecycle
  SpixiAppSdk.onInit = function(sessionId, addresses){
    IN_SPXI = true;
    // start the game when Spixi loads us
    loop();
  };

  // Fire onload if inside Spixi, otherwise run standalone
  window.addEventListener('load', () => {
    try {
      SpixiAppSdk.fireOnLoad();
      // If we're in Spixi, onInit will be called by host and then loop() will start.
      // To avoid double start, don't start loop here.
      setTimeout(() => {
        if (!IN_SPXI) {
          // Fallback for browser testing
          loop();
        }
      }, 400);
    } catch(e) {
      // Standalone browser
      loop();
    }
  });
})();
